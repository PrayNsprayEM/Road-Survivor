# Road Survivor

Upload `index.html` to GitHub. On Render use a Static Site, branch `main`, blank build command, publish directory `.`, Auto Deploy on.

Mobile landscape top-down traffic survival game with Easy/Medium/Hard/Extreme, button/gyro controls, under-30-MPH pause, crash screen, leaderboard, $10,000 starter cash, and upgrades.